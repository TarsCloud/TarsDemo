<?php
return [
    'appName' => 'Demo', // 对应部署服务的应用名称
    'serverName' => 'PHPHttp', // 对应部署服务的服务名称
    'objName' => 'HelloObj', // 对应部署服务的obj
];
