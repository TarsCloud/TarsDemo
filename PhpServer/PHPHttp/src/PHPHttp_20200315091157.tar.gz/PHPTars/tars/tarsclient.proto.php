<?php
return array(
    'appName' => 'Demo',
    'serverName' => 'PHPTars',
    'objName' => 'HelloObj',
    'withServant' => true,
    'tarsFiles' => array(
        './php.tars',
    ),
    'dstPath' => '../src/servant',
    'namespacePrefix' => 'PHPTars\servant',
);
