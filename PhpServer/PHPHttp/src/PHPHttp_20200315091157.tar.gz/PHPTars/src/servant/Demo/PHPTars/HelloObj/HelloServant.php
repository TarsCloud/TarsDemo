<?php

namespace PHPTars\servant\Demo\PHPTars\HelloObj;

interface HelloServant {
	/**
	 * @return string
	 */
	public function ping();
}

