<?php
return [
    'HelloObj' => [
        'home-api' => '\PHPTars\servant\Demo\PHPTars\HelloObj\HelloServant',
        'home-class' => '\PHPTars\impl\Demo',
        'protocolName' => 'tars',
        'serverType' => 'tcp',
    ],
];
